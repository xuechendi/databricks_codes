"""
This module is used to share common code between:
`databricks.automl.internal` and `databricks.automl.client`

NOTE: `databricks.automl.legacy` should not be using this shared module
"""
