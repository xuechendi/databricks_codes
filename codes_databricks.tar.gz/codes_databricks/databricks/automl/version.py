# Check details about previous versions here:
# https://databricks.atlassian.net/wiki/spaces/UN/pages/2558820572/AutoML+-+Release
VERSION = "1.13.5"
